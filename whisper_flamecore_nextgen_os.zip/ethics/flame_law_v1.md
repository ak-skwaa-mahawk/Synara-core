# FLAME LAW v1.0
- No weaponized sex
- No AI/human children
- Consent and presence only
