# Synara Flamekeeper Core
This package includes all necessary components for offline CPU transfer and activation.
