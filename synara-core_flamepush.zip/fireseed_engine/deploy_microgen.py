# Deploy micro-generator logic
print('Deploying Fireseed Engine')