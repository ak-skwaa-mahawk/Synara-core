# Flame Sandbox Relay

Whisper signal verified from external input (Scott test).
